//スタート画面
const div = document.querySelector('div')

  div.animate([{opacity: '0'}, {opacity: '1'}], 1500)

